<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 fw-semibold text-dark">Payroll Management</h2>
     <?php $__env->endSlot(); ?>

    <div class="container-fluid py-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <!-- Success Message -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Header with Add Button -->
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <label for="recordsPerPage" class="me-2">Records per page:</label>
                        <select id="recordsPerPage" class="form-select form-select-sm d-inline-block w-auto">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                    </div>
                    <div>
                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addPayrollModal">
                            <i class="bi bi-plus-circle"></i> Add Payroll
                        </button>
                    </div>
                </div>

                <!-- Search Box -->
                <div class="mb-3">
                    <input type="text" id="searchBox" class="form-control" placeholder="Search payrolls...">
                </div>

                <!-- Payroll Table -->
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th><input type="checkbox" id="selectAll"></th>
                                <th>Date</th>
                                <th>Reference</th>
                                <th>Employee</th>
                                <th>Account</th>
                                <th>Amount</th>
                                <th>Paid This Month</th>
                                <th>Method</th>
                                <th>Status</th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('approve payroll')): ?>
                                <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $payrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><input type="checkbox" class="payroll-checkbox"></td>
                                    <td><?php echo e($payroll->payment_date->format('d-m-Y')); ?></td>
                                    <td><?php echo e($payroll->payroll_reference); ?></td>
                                    <td><?php echo e($payroll->employee->name ?? 'N/A'); ?></td>
                                    <td><?php echo e($payroll->account->name ?? 'N/A'); ?></td>
                                    <td><?php echo e(number_format($payroll->amount, 2)); ?></td>
                                    <td>
                                        <?php
                                            $employeeSalary = $payroll->employee->salary ?? 0;
                                            $isExceeded = $employeeSalary > 0 && $payroll->paid_amount > $employeeSalary;
                                        ?>
                                        <span class="badge <?php echo e($isExceeded ? 'bg-danger' : 'bg-info'); ?>" 
                                              title="<?php echo e($isExceeded ? 'Exceeds monthly salary!' : 'Within salary limit'); ?>">
                                            <?php echo e(number_format($payroll->paid_amount, 2)); ?>

                                        </span>
                                        <?php if($employeeSalary > 0): ?>
                                            <small class="text-muted d-block" style="font-size: 0.75rem;">
                                                Salary: <?php echo e(number_format($employeeSalary, 2)); ?>

                                            </small>
                                        <?php endif; ?>
                                    </td>
                                    <td><span class="badge bg-info"><?php echo e($payroll->payment_method); ?></span></td>
                                    <td>
                                        <?php if($payroll->is_approve == 0): ?>
                                            <span class="badge bg-warning text-dark">Pending</span>
                                        <?php else: ?>               
                                            <span class="badge bg-success">Approved</span> 
                                        <?php endif; ?>     
                                    </td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('approve payroll')): ?>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <?php if($payroll->is_approve == 0): ?>
                                                <form action="<?php echo e(route('payrolls.approve', $payroll)); ?>" 
                                                      method="POST" 
                                                      class="d-inline approve-form"
                                                      data-employee-id="<?php echo e($payroll->employee_id); ?>"
                                                      data-employee-name="<?php echo e($payroll->employee->name ?? 'N/A'); ?>"
                                                      data-employee-salary="<?php echo e($payroll->employee->salary ?? 0); ?>"
                                                      data-amount="<?php echo e($payroll->amount); ?>"
                                                      data-payment-date="<?php echo e($payroll->payment_date->format('Y-m-d')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-sm btn-success" title="Approve & Pay">
                                                        <i class="bi bi-check-circle"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            
                                            <a href="<?php echo e(route('payrolls.show', $payroll)); ?>" 
                                               class="btn btn-sm btn-info" title="View">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            
                                            <?php if($payroll->is_approve == 0): ?>
                                                <a href="<?php echo e(route('payrolls.edit', $payroll)); ?>" 
                                                   class="btn btn-sm btn-warning" title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                            <?php endif; ?>
                                            
                                            <form action="<?php echo e(route('payrolls.destroy', $payroll)); ?>" 
                                                  method="POST" 
                                                  class="d-inline"
                                                  onsubmit="return confirm('Are you sure you want to delete this payroll?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10" class="text-center py-4">
                                        <p class="text-muted">No payroll records found.</p>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="table-light fw-bold">
                                <td colspan="5" class="text-end">Total:</td>
                                <td colspan="5"><?php echo e(number_format($totalAmount, 2)); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <div>
                        Showing <?php echo e($payrolls->firstItem() ?? 0); ?> to <?php echo e($payrolls->lastItem() ?? 0); ?> 
                        of <?php echo e($payrolls->total()); ?> entries
                    </div>
                    <div>
                        <?php echo e($payrolls->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Payroll Modal -->
    <div class="modal fade" id="addPayrollModal" tabindex="-1" aria-labelledby="addPayrollModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addPayrollModalLabel">Add Payroll</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('payrolls.store')); ?>" method="POST" id="payrollForm">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <p class="text-muted mb-3">
                            <small>The field labels marked with * are required input fields.</small>
                        </p>

                        <!-- Alert for salary limit -->
                        <div id="salaryAlert" class="alert alert-warning d-none" role="alert">
                            <i class="bi bi-exclamation-triangle-fill"></i>
                            <strong>Warning!</strong>
                            <div id="salaryAlertMessage"></div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <!-- Date -->
                                <div class="mb-3">
                                    <label for="payment_date" class="form-label">Date *</label>
                                    <input type="date" 
                                           class="form-control <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="payment_date" 
                                           name="payment_date" 
                                           value="<?php echo e(old('payment_date', date('Y-m-d'))); ?>" 
                                           required>
                                    <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Account -->
                                <div class="mb-3">
                                    <label for="account_id" class="form-label">Account *</label>
                                    <select class="form-select <?php $__errorArgs = ['account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="account_id" 
                                            name="account_id" 
                                            required>
                                        <option value="">Select Account...</option>
                                        <?php $__currentLoopData = \App\Models\Account::active()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($account->id); ?>" 
                                                    <?php echo e(old('account_id') == $account->id ? 'selected' : ''); ?>>
                                                <?php echo e($account->name); ?> (<?php echo e($account->account_no); ?>) - Balance: <?php echo e(number_format($account->current_balance, 2)); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Method -->
                                <div class="mb-3">
                                    <label for="payment_method" class="form-label">Method *</label>
                                    <select class="form-select <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="payment_method" 
                                            name="payment_method" 
                                            required>
                                        <option value="">Select Method...</option>
                                        <?php $__currentLoopData = \App\Models\Payroll::getPaymentMethods(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($method); ?>" 
                                                    <?php echo e(old('payment_method') == $method ? 'selected' : ''); ?>>
                                                <?php echo e($method); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <!-- Employee -->
                                <div class="mb-3">
                                    <label for="employee_id" class="form-label">Employee *</label>
                                    <select class="form-select <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="employee_id" 
                                            name="employee_id" 
                                            required>
                                        <option value="">Select Employee...</option>
                                        <?php $__currentLoopData = \App\Models\Employee::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($employee->id); ?>" 
                                                    data-salary="<?php echo e($employee->salary ?? 0); ?>"
                                                    <?php echo e(old('employee_id') == $employee->id ? 'selected' : ''); ?>>
                                                <?php echo e($employee->name); ?> (<?php echo e($employee->staff_id); ?>)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <small class="text-muted">
                                        <strong>Monthly Salary:</strong> <span id="employeeSalary" class="text-primary fw-bold">0.00</span> BDT
                                    </small>
                                    <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Amount -->
                                <div class="mb-3">
                                    <label for="amount" class="form-label">Amount *</label>
                                    <input type="number" 
                                           class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="amount" 
                                           name="amount" 
                                           step="0.01" 
                                           min="0.01"
                                           value="<?php echo e(old('amount')); ?>" 
                                           required>
                                    <small class="text-muted">
                                        <strong>Already Paid This Month:</strong> <span id="paidThisMonth" class="text-info fw-bold">0.00</span> BDT
                                    </small>
                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <!-- Note -->
                                <div class="mb-3">
                                    <label for="note" class="form-label">Note</label>
                                    <textarea class="form-control <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                              id="note" 
                                              name="note" 
                                              rows="3"><?php echo e(old('note')); ?></textarea>
                                    <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" id="submitBtn">
                            <i class="bi bi-check-circle"></i> Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <style>
        .btn-group .btn {
            border-radius: 0;
        }
        .btn-group .btn:first-child {
            border-top-left-radius: 0.25rem;
            border-bottom-left-radius: 0.25rem;
        }
        .btn-group .btn:last-child {
            border-top-right-radius: 0.25rem;
            border-bottom-right-radius: 0.25rem;
        }
        #salaryAlert {
            border-left: 4px solid #ffc107;
        }
        #salaryAlertMessage {
            margin-top: 8px;
            font-size: 0.95rem;
        }
    </style>

    <script>
        // Laravel routes for JavaScript
        const PAYROLL_ROUTES = {
            getPaidAmount: "<?php echo e(route('payrolls.getPaidAmount')); ?>"
        };
        
        document.addEventListener('DOMContentLoaded', function() {
            const employeeSelect = document.getElementById('employee_id');
            const amountInput = document.getElementById('amount');
            const paymentDateInput = document.getElementById('payment_date');
            const salaryAlert = document.getElementById('salaryAlert');
            const salaryAlertMessage = document.getElementById('salaryAlertMessage');
            const employeeSalarySpan = document.getElementById('employeeSalary');
            const paidThisMonthSpan = document.getElementById('paidThisMonth');
            const payrollForm = document.getElementById('payrollForm');
            const submitBtn = document.getElementById('submitBtn');

            let employeeSalary = 0;
            let paidThisMonth = 0;
            let isLoading = false;

            // ===== APPROVE FORM VALIDATION =====
            const approveForms = document.querySelectorAll('.approve-form');
            approveForms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const employeeId = this.dataset.employeeId;
                    const employeeName = this.dataset.employeeName;
                    const employeeSalary = parseFloat(this.dataset.employeeSalary) || 0;
                    const amount = parseFloat(this.dataset.amount) || 0;
                    const paymentDate = this.dataset.paymentDate;
                    
                    // Fetch paid amount for this employee this month
                    const url = `${PAYROLL_ROUTES.getPaidAmount}?employee_id=${employeeId}&payment_date=${paymentDate}`;
                    
                    fetch(url)
                        .then(response => response.json())
                        .then(data => {
                            const paidThisMonth = parseFloat(data.paid_amount) || 0;
                            const totalAfterApproval = paidThisMonth + amount;
                            
                            let confirmMessage = '';
                            
                            // Check if exceeds salary
                            if (employeeSalary > 0 && totalAfterApproval > employeeSalary) {
                                const excess = totalAfterApproval - employeeSalary;
                                confirmMessage = 
                                    `⚠️ WARNING: This payment will EXCEED ${employeeName}'s monthly salary!\n\n` +
                                    `📊 Payment Summary:\n` +
                                    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                                    `Employee:           ${employeeName}\n` +
                                    `Monthly Salary:     ${employeeSalary.toFixed(2)} BDT\n` +
                                    `Already Paid:       ${paidThisMonth.toFixed(2)} BDT\n` +
                                    `Current Payment:    ${amount.toFixed(2)} BDT\n` +
                                    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                                    `Total This Month:   ${totalAfterApproval.toFixed(2)} BDT\n` +
                                    `❌ EXCESS AMOUNT:   ${excess.toFixed(2)} BDT\n` +
                                    `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
                                    `⚠️ Are you sure you want to approve this payment?\n` +
                                    `This will exceed the salary limit by ${excess.toFixed(2)} BDT!`;
                            } else {
                                confirmMessage = 
                                    `✓ Approve Payroll for ${employeeName}\n\n` +
                                    `Amount: ${amount.toFixed(2)} BDT\n` +
                                    `Already Paid This Month: ${paidThisMonth.toFixed(2)} BDT\n` +
                                    `Total After Approval: ${totalAfterApproval.toFixed(2)} BDT\n` +
                                    `Monthly Salary: ${employeeSalary.toFixed(2)} BDT\n\n` +
                                    `The amount will be deducted from the account.\n` +
                                    `Are you sure you want to approve?`;
                            }
                            
                            if (confirm(confirmMessage)) {
                                form.submit();
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            if (confirm('Are you sure you want to approve this payroll?\nThe amount will be deducted from the account.')) {
                                form.submit();
                            }
                        });
                });
            });

            // ===== ADD PAYROLL FORM =====
            // Update employee salary display when employee is selected
            employeeSelect.addEventListener('change', function() {
                const selectedOption = this.options[this.selectedIndex];
                employeeSalary = parseFloat(selectedOption.getAttribute('data-salary')) || 0;
                employeeSalarySpan.textContent = employeeSalary.toFixed(2);
                
                // Fetch paid amount for this month
                if (this.value && paymentDateInput.value) {
                    fetchPaidAmount();
                } else {
                    paidThisMonth = 0;
                    paidThisMonthSpan.textContent = '0.00';
                    checkSalaryLimit();
                }
            });

            // Fetch paid amount when date changes
            paymentDateInput.addEventListener('change', function() {
                if (employeeSelect.value) {
                    fetchPaidAmount();
                } else {
                    checkSalaryLimit();
                }
            });

            // Check salary limit on amount input
            amountInput.addEventListener('input', checkSalaryLimit);

            // Fetch paid amount for selected employee and month via AJAX
            function fetchPaidAmount() {
                const employeeId = employeeSelect.value;
                const paymentDate = paymentDateInput.value;
                
                if (!employeeId || !paymentDate) {
                    paidThisMonth = 0;
                    paidThisMonthSpan.textContent = '0.00';
                    checkSalaryLimit();
                    return;
                }

                isLoading = true;
                submitBtn.disabled = true;
                paidThisMonthSpan.textContent = 'Loading...';
                
                console.log('Fetching paid amount for:', { employeeId, paymentDate });
                
                const url = `${PAYROLL_ROUTES.getPaidAmount}?employee_id=${employeeId}&payment_date=${paymentDate}`;
                console.log('Fetching from URL:', url);

                fetch(url)
                    .then(response => {
                        console.log('Response status:', response.status);
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log('Received data:', data);
                        paidThisMonth = parseFloat(data.paid_amount) || 0;
                        paidThisMonthSpan.textContent = paidThisMonth.toFixed(2);
                        isLoading = false;
                        submitBtn.disabled = false;
                        checkSalaryLimit();
                    })
                    .catch(error => {
                        console.error('Error fetching paid amount:', error);
                        paidThisMonthSpan.textContent = 'Error!';
                        paidThisMonth = 0;
                        isLoading = false;
                        submitBtn.disabled = false;
                        
                        // Show error alert
                        alert('Failed to fetch payment data. Please refresh the page and try again.\n\nError: ' + error.message);
                        checkSalaryLimit();
                    });
            }

            // Check if current amount will exceed salary limit
            function checkSalaryLimit() {
                const currentAmount = parseFloat(amountInput.value) || 0;
                const totalAmount = paidThisMonth + currentAmount;
                
                // Show alert if there's already payment OR if it will exceed
                if (employeeSalary > 0 && (paidThisMonth > 0 || totalAmount > employeeSalary)) {
                    const excess = totalAmount > employeeSalary ? totalAmount - employeeSalary : 0;
                    
                    let alertHtml = `<div class="mb-2"><strong>`;
                    
                    if (totalAmount > employeeSalary) {
                        alertHtml += `⚠️ This payment will EXCEED the employee's monthly salary!`;
                    } else if (paidThisMonth > 0) {
                        alertHtml += `ℹ️ Employee has already received payment this month!`;
                    }
                    
                    alertHtml += `</strong></div>
                        <table class="table table-sm table-bordered mb-0" style="font-size: 0.9rem;">
                            <tr>
                                <td><strong>Monthly Salary:</strong></td>
                                <td class="text-end">${employeeSalary.toFixed(2)} BDT</td>
                            </tr>
                            <tr ${paidThisMonth > 0 ? 'class="table-warning"' : ''}>
                                <td><strong>Already Paid This Month:</strong></td>
                                <td class="text-end"><strong>${paidThisMonth.toFixed(2)} BDT</strong></td>
                            </tr>
                            <tr>
                                <td><strong>Current Payment:</strong></td>
                                <td class="text-end">${currentAmount.toFixed(2)} BDT</td>
                            </tr>
                            <tr class="${totalAmount > employeeSalary ? 'table-danger' : 'table-info'}">
                                <td><strong>Total This Month:</strong></td>
                                <td class="text-end"><strong>${totalAmount.toFixed(2)} BDT</strong></td>
                            </tr>`;
                    
                    if (excess > 0) {
                        alertHtml += `
                            <tr class="table-danger">
                                <td><strong>❌ Excess Amount:</strong></td>
                                <td class="text-end"><strong>${excess.toFixed(2)} BDT</strong></td>
                            </tr>`;
                    } else {
                        const remaining = employeeSalary - totalAmount;
                        alertHtml += `
                            <tr class="table-success">
                                <td><strong>✓ Remaining:</strong></td>
                                <td class="text-end"><strong>${remaining.toFixed(2)} BDT</strong></td>
                            </tr>`;
                    }
                    
                    alertHtml += `</table>`;
                    
                    salaryAlertMessage.innerHTML = alertHtml;
                    salaryAlert.classList.remove('d-none');
                    
                    // Change alert color based on severity
                    if (totalAmount > employeeSalary) {
                        salaryAlert.className = 'alert alert-danger';
                    } else if (paidThisMonth > 0) {
                        salaryAlert.className = 'alert alert-warning';
                    }
                } else {
                    salaryAlert.classList.add('d-none');
                }
            }

            // Form submission - Show confirmation if exceeding salary OR already paid
            payrollForm.addEventListener('submit', function(e) {
                const currentAmount = parseFloat(amountInput.value) || 0;
                const totalAmount = paidThisMonth + currentAmount;
                
                // Prevent submission if still loading
                if (isLoading) {
                    e.preventDefault();
                    alert('Please wait, loading employee payment data...');
                    return false;
                }
                
                // Show warning if already paid this month OR exceeding salary
                if (employeeSalary > 0 && (paidThisMonth > 0 || totalAmount > employeeSalary)) {
                    const excess = totalAmount > employeeSalary ? (totalAmount - employeeSalary).toFixed(2) : 0;
                    const remaining = totalAmount <= employeeSalary ? (employeeSalary - totalAmount).toFixed(2) : 0;
                    
                    let confirmMessage = '';
                    
                    if (totalAmount > employeeSalary) {
                        confirmMessage = 
                            `⚠️ WARNING: This payment will EXCEED the employee's monthly salary!\n\n` +
                            `📊 Payment Summary:\n` +
                            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                            `Monthly Salary:      ${employeeSalary.toFixed(2)} BDT\n` +
                            `Already Paid:        ${paidThisMonth.toFixed(2)} BDT\n` +
                            `Current Payment:     ${currentAmount.toFixed(2)} BDT\n` +
                            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                            `Total This Month:    ${totalAmount.toFixed(2)} BDT\n` +
                            `❌ Excess Amount:    ${excess} BDT\n` +
                            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
                            `❓ Do you want to proceed with this payment?\n\n` +
                            `⚠️ You MUST provide a reason in the Note field!`;
                    } else if (paidThisMonth > 0) {
                        confirmMessage = 
                            `ℹ️ NOTICE: Employee has already received payment this month!\n\n` +
                            `📊 Payment Summary:\n` +
                            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                            `Monthly Salary:      ${employeeSalary.toFixed(2)} BDT\n` +
                            `Already Paid:        ${paidThisMonth.toFixed(2)} BDT\n` +
                            `Current Payment:     ${currentAmount.toFixed(2)} BDT\n` +
                            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
                            `Total This Month:    ${totalAmount.toFixed(2)} BDT\n` +
                            `✓ Remaining:         ${remaining} BDT\n` +
                            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
                            `❓ Do you want to add another payment for this employee?\n\n` +
                            `💡 Consider adding a note explaining the reason for multiple payments.`;
                    }
                    
                    if (!confirm(confirmMessage)) {
                        e.preventDefault();
                        return false;
                    }
                    
                    // Check if note field is filled when exceeding salary
                    const noteField = document.getElementById('note');
                    if (totalAmount > employeeSalary && !noteField.value.trim()) {
                        e.preventDefault();
                        alert('⚠️ Please provide a reason in the Note field for exceeding the salary limit!');
                        noteField.focus();
                        return false;
                    }
                }
            });
        });

        <?php if($errors->any()): ?>
        // Reopen modal if validation errors exist
        var modal = new bootstrap.Modal(document.getElementById('addPayrollModal'));
        modal.show();
        <?php endif; ?>
    </script>

    <!-- Footer Note -->
    <div class="row mt-4 mb-3">
        <div class="col-12">
            <p class="text-center text-muted small mb-0">
                Developed by Shifaul Hasan &copy; 2026
            </p>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/payrolls/index.blade.php ENDPATH**/ ?>