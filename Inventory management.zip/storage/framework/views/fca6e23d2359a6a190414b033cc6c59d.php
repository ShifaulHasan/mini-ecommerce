<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="h4 fw-semibold mb-0">Purchase Details</h2>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('purchases.index')); ?>" class="btn btn-sm btn-primary">
                    <i class="bi bi-arrow-left"></i> Back to List
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-md-8">

            <!-- Purchase Information -->
            <div class="card mb-3">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Purchase Information</h5>
                </div>
                <div class="card-body">

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Reference Number:</strong>
                            <p><?php echo e($purchase->reference_no); ?></p>
                        </div>
                        <div class="col-md-6">
                            <strong>Purchase Date:</strong>
                            <p><?php echo e(\Carbon\Carbon::parse($purchase->purchase_date)->format('d M Y')); ?></p>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Supplier:</strong>
                            <p>
                                <?php if($purchase->supplier_type === 'supplier'): ?>
                                    <?php echo e($purchase->supplierModel->name ?? 'N/A'); ?>

                                    <?php if($purchase->supplierModel && $purchase->supplierModel->company): ?>
                                        <small class="text-muted">(<?php echo e($purchase->supplierModel->company); ?>)</small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php echo e($purchase->userSupplier->name ?? 'N/A'); ?>

                                    <small class="text-muted">(User Account)</small>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <strong>Warehouse:</strong>
                            <p><?php echo e($purchase->warehouse->name ?? 'N/A'); ?></p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <strong>Status:</strong>
                            <p>
                                <span class="badge bg-<?php echo e($purchase->purchase_status === 'received' ? 'success' : ($purchase->purchase_status === 'pending' ? 'warning' : 'danger')); ?>">
                                    <?php echo e(ucfirst($purchase->purchase_status)); ?>

                                </span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <strong>Payment Status:</strong>
                            <p>
                                <span class="badge bg-<?php echo e($purchase->payment_status === 'paid' ? 'success' : ($purchase->payment_status === 'partial' ? 'info' : 'danger')); ?>">
                                    <?php echo e(ucfirst($purchase->payment_status)); ?>

                                </span>
                            </p>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Purchased Products -->
            <div class="card mb-3">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="bi bi-box-seam"></i> Purchased Products</h5>
                </div>
                <div class="card-body">
                    <?php if($purchase->items && count($purchase->items) > 0): ?>
                        <?php
                            $itemsTotal = 0;
                        ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th width="50" class="text-center">#</th>
                                        <th>Product Name</th>
                                        <th width="120" class="text-center">Quantity</th>
                                        <th width="150" class="text-end">Unit Price</th>
                                        <th width="150" class="text-end">Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $itemSubtotal = $item->quantity * $item->cost_price;
                                            $itemsTotal += $itemSubtotal;
                                        ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($index + 1); ?></td>
                                            <td>
                                                <strong><?php echo e($item->product->name ?? 'N/A'); ?></strong>
                                                <?php if($item->product && $item->product->product_code): ?>
                                                    <br><small class="text-muted">Code: <?php echo e($item->product->product_code); ?></small>
                                                <?php endif; ?>
                                                <?php if($item->batch_id): ?>
                                                    <br><small class="text-info">Batch: <?php echo e($item->batch_id); ?></small>
                                                <?php endif; ?>
                                                <?php if($item->expiry_date): ?>
                                                    <br><small class="text-warning">Exp: <?php echo e(\Carbon\Carbon::parse($item->expiry_date)->format('d M Y')); ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <span class="badge bg-primary fs-6"><?php echo e(number_format($item->quantity, 0)); ?></span>
                                            </td>
                                            <td class="text-end">
                                                <strong>৳<?php echo e(number_format($item->cost_price, 2)); ?></strong>
                                            </td>
                                            <td class="text-end">
                                                <strong class="text-primary fs-6">
                                                    ৳<?php echo e(number_format($itemSubtotal, 2)); ?>

                                                </strong>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot class="table-light">
                                    <tr>
                                        <td colspan="4" class="text-end"><strong>Total Amount:</strong></td>
                                        <td class="text-end">
                                            <strong class="text-primary fs-5">
                                                ৳<?php echo e(number_format($itemsTotal, 2)); ?>

                                            </strong>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center text-muted py-4">
                            <i class="bi bi-inbox fs-1"></i>
                            <p class="mb-0">No products found in this purchase</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>

        <!-- Payment Summary Sidebar -->
        <div class="col-md-4">

            <div class="card mb-3">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">Payment Summary</h5>
                </div>
                <div class="card-body">

                    <?php
                        // Calculate subtotal from items if not set
                        $subtotal = $purchase->subtotal ?? $purchase->total ?? 0;
                        if ($subtotal == 0 && $purchase->items) {
                            foreach ($purchase->items as $item) {
                                $subtotal += ($item->quantity * $item->cost_price);
                            }
                        }

                        // Get other values
                        $taxAmount = $purchase->tax_amount ?? 0;
                        $discountAmount = $purchase->discount_amount ?? 0;
                        $shippingCost = $purchase->shipping_cost ?? 0;

                        // Calculate grand total
                        $grandTotal = $purchase->grand_total ?? ($subtotal + $taxAmount - $discountAmount + $shippingCost);

                        // Get payment amounts
                        $paidAmount = $purchase->paid_amount ?? 0;
                        $dueAmount = $purchase->due_amount ?? ($grandTotal - $paidAmount);
                    ?>

                    <div class="d-flex justify-content-between mb-2">
                        <span>Subtotal:</span>
                        <strong>৳<?php echo e(number_format($subtotal, 2)); ?></strong>
                    </div>

                    <?php if($taxAmount > 0): ?>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Tax (<?php echo e($purchase->tax_percentage ?? 0); ?>%):</span>
                        <strong class="text-success">৳<?php echo e(number_format($taxAmount, 2)); ?></strong>
                    </div>
                    <?php endif; ?>

                    <?php if($discountAmount > 0): ?>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Discount:</span>
                        <strong class="text-danger">-৳<?php echo e(number_format($discountAmount, 2)); ?></strong>
                    </div>
                    <?php endif; ?>

                    <?php if($shippingCost > 0): ?>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Shipping:</span>
                        <strong>৳<?php echo e(number_format($shippingCost, 2)); ?></strong>
                    </div>
                    <?php endif; ?>

                    <hr>

                    <div class="d-flex justify-content-between mb-2">
                        <span><strong>Grand Total:</strong></span>
                        <strong class="text-primary fs-5">৳<?php echo e(number_format($grandTotal, 2)); ?></strong>
                    </div>

                    <div class="d-flex justify-content-between mb-2">
                        <span>Paid:</span>
                        <strong class="text-success">৳<?php echo e(number_format($paidAmount, 2)); ?></strong>
                    </div>

                    <div class="d-flex justify-content-between">
                        <span>Due:</span>
                        <strong class="text-danger">৳<?php echo e(number_format($dueAmount, 2)); ?></strong>
                    </div>

                </div>
            </div>

            <?php if($purchase->payment_method): ?>
            <div class="card mb-3">
                <div class="card-header">
                    <h6 class="mb-0"><i class="bi bi-credit-card"></i> Payment Info</h6>
                </div>
                <div class="card-body">
                    <div class="mb-2">
                        <strong>Payment Method:</strong>
                        <p class="mb-0"><?php echo e(ucfirst($purchase->payment_method)); ?></p>
                    </div>
                    <?php if($purchase->account): ?>
                    <!-- <div>
                        <strong>Account:</strong>
                        <p class="mb-0"><?php echo e($purchase->account->account_name); ?></p>
                    </div> -->
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if($purchase->notes): ?>
            <div class="card mb-3">
                <div class="card-header">
                    <h6 class="mb-0"><i class="bi bi-file-text"></i> Notes</h6>
                </div>
                <div class="card-body">
                    <p class="mb-0"><?php echo e($purchase->notes); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <?php if($purchase->document_path): ?>
            <div class="card mb-3">
                <div class="card-header">
                    <h6 class="mb-0"><i class="bi bi-paperclip"></i> Attachment</h6>
                </div>
                <div class="card-body">
                    <a href="<?php echo e(asset($purchase->document_path)); ?>" target="_blank" class="btn btn-sm btn-outline-primary w-100">
                        <i class="bi bi-download"></i> Download Document
                    </a>
                </div>
            </div>
            <?php endif; ?>

            <!-- Action Buttons -->
            <div class="card">
                <div class="card-body">
                    <div class="d-grid gap-2">

                        <a href="<?php echo e(route('purchases.edit', $purchase)); ?>" class="btn btn-warning">
                            <i class="bi bi-pencil"></i> Edit Purchase
                        </a>

                        <form action="<?php echo e(route('purchases.destroy', $purchase)); ?>" 
                              method="POST"
                              onsubmit="return confirm('Are you sure you want to delete this purchase?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger w-100">
                                <i class="bi bi-trash"></i> Delete Purchase
                            </button>
                        </form>

                    </div>
                </div>
            </div>

        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/purchases/show.blade.php ENDPATH**/ ?>