<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row mb-4">
            <div class="col-12">
                <h2 class="h4 fw-bold text-dark">
                    <i class="bi bi-person-badge"></i> Role Permission Management
                </h2>
            </div>
        </div>

        
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle"></i> <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        
        <?php
            $superAdmin = $roles->firstWhere('name', 'super-admin');
        ?>
        
        <?php if($superAdmin): ?>
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-gradient" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                    <h5 class="mb-0 text-white">
                        <i class="bi bi-shield-fill-check"></i> <?php echo e(ucfirst($superAdmin->name)); ?>

                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('roles.permissions.assign', $superAdmin->id)); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row g-2">
                            <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-4 col-lg-3">
                                    <div class="form-check">
                                        <input class="form-check-input" 
                                               type="checkbox"
                                               name="permissions[]"
                                               value="<?php echo e($permission->name); ?>"
                                               id="perm_<?php echo e($superAdmin->id); ?>_<?php echo e($permission->id); ?>"
                                               <?php echo e($superAdmin->hasPermissionTo($permission->name) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="perm_<?php echo e($superAdmin->id); ?>_<?php echo e($permission->id); ?>">
                                            <?php echo e($permission->name); ?>

                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-12">
                                    <p class="text-muted mb-0">No permissions available.</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <hr class="my-3">

                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-lg"></i> Save Permissions
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        
        <?php
            $admin = $roles->firstWhere('name', 'admin');
        ?>
        
        <?php if($admin): ?>
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-gradient" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                    <h5 class="mb-0 text-white">
                        <i class="bi bi-award"></i> <?php echo e(ucfirst($admin->name)); ?>

                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('roles.permissions.assign', $admin->id)); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row g-2">
                            <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-4 col-lg-3">
                                    <div class="form-check">
                                        <input class="form-check-input" 
                                               type="checkbox"
                                               name="permissions[]"
                                               value="<?php echo e($permission->name); ?>"
                                               id="perm_<?php echo e($admin->id); ?>_<?php echo e($permission->id); ?>"
                                               <?php echo e($admin->hasPermissionTo($permission->name) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="perm_<?php echo e($admin->id); ?>_<?php echo e($permission->id); ?>">
                                            <?php echo e($permission->name); ?>

                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-12">
                                    <p class="text-muted mb-0">No permissions available.</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <hr class="my-3">

                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-lg"></i> Save Permissions
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        
        <?php
            $staff = $roles->firstWhere('name', 'staff');
        ?>
        
        <?php if($staff): ?>
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-gradient" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                    <h5 class="mb-0 text-white">
                        <i class="bi bi-person-badge"></i> <?php echo e(ucfirst($staff->name)); ?>

                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('roles.permissions.assign', $staff->id)); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row g-2">
                            <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-4 col-lg-3">
                                    <div class="form-check">
                                        <input class="form-check-input" 
                                               type="checkbox"
                                               name="permissions[]"
                                               value="<?php echo e($permission->name); ?>"
                                               id="perm_<?php echo e($staff->id); ?>_<?php echo e($permission->id); ?>"
                                               <?php echo e($staff->hasPermissionTo($permission->name) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="perm_<?php echo e($staff->id); ?>_<?php echo e($permission->id); ?>">
                                            <?php echo e($permission->name); ?>

                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-12">
                                    <p class="text-muted mb-0">No permissions available.</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <hr class="my-3">

                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-lg"></i> Save Permissions
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        
        <?php $__currentLoopData = $roles->whereNotIn('name', ['super-admin', 'admin', 'staff']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-secondary text-white">
                    <h5 class="mb-0">
                        <i class="bi bi-award"></i> <?php echo e(ucfirst($role->name)); ?>

                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('roles.permissions.assign', $role->id)); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row g-2">
                            <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-4 col-lg-3">
                                    <div class="form-check">
                                        <input class="form-check-input" 
                                               type="checkbox"
                                               name="permissions[]"
                                               value="<?php echo e($permission->name); ?>"
                                               id="perm_<?php echo e($role->id); ?>_<?php echo e($permission->id); ?>"
                                               <?php echo e($role->hasPermissionTo($permission->name) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="perm_<?php echo e($role->id); ?>_<?php echo e($permission->id); ?>">
                                            <?php echo e($permission->name); ?>

                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-12">
                                    <p class="text-muted mb-0">No permissions available.</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <hr class="my-3">

                        <button type="submit" class="btn btn-success">
                            <i class="bi bi-check-lg"></i> Save Permissions
                        </button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($roles->isEmpty()): ?>
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle"></i> No roles found. Please create roles first.
            </div>
        <?php endif; ?>
    </div>
    <!-- Footer Note -->
    <div class="row mt-4 mb-3">
        <div class="col-12">
            <p class="text-center text-muted small mb-0">
                Developed by Shifaul Hasan &copy; 2026
            </p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/role-permission/roles.blade.php ENDPATH**/ ?>