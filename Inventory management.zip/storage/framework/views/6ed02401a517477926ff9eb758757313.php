<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="h4 fw-semibold mb-0">Purchase List</h2>
            <div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create purchases')): ?>
                <a href="<?php echo e(route('purchases.create')); ?>" class="btn btn-primary btn-sm me-2">
                    <i class="bi bi-plus-circle"></i> Add Purchase
                </a>
                <?php endif; ?> 
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show mt-3">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Filters -->
    <div class="card mt-3 mb-3">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('purchases.index')); ?>">
                <div class="row g-3">

                    <div class="col-md-2">
                        <label class="form-label small">Start Date</label>
                        <input type="date" name="start_date" class="form-control form-control-sm"
                               value="<?php echo e(request('start_date')); ?>">
                    </div>

                    <div class="col-md-2">
                        <label class="form-label small">End Date</label>
                        <input type="date" name="end_date" class="form-control form-control-sm"
                               value="<?php echo e(request('end_date')); ?>">
                    </div>

                    <div class="col-md-2">
                        <label class="form-label small">Warehouse</label>
                        <select name="warehouse_id" class="form-select form-select-sm">
                            <option value="">All</option>
                            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($warehouse->id); ?>" 
                                    <?php echo e(request('warehouse_id') == $warehouse->id ? 'selected' : ''); ?>>
                                    <?php echo e($warehouse->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label class="form-label small">Payment Status</label>
                        <select name="payment_status" class="form-select form-select-sm">
                            <option value="">All</option>
                            <option value="unpaid" <?php echo e(request('payment_status')=='unpaid'?'selected':''); ?>>Unpaid</option>
                            <option value="partial" <?php echo e(request('payment_status')=='partial'?'selected':''); ?>>Partial</option>
                            <option value="paid" <?php echo e(request('payment_status')=='paid'?'selected':''); ?>>Paid</option>
                        </select>
                    </div>

                    <div class="col-md-2 d-flex align-items-end">
                        <button class="btn btn-primary btn-sm w-100">
                            <i class="bi bi-funnel"></i> Filter
                        </button>
                    </div>

                </div>
            </form>
        </div>
    </div>

    <!-- Table -->
    <div class="card">
        <div class="card-body">

            <!-- Search -->
            <div class="row mb-3">
                <div class="col-md-4">
                    <form method="GET" class="d-flex gap-2">
                        <input type="text" class="form-control form-control-sm"
                               name="search" value="<?php echo e(request('search')); ?>"
                               placeholder="Search reference / supplier">

                        <button class="btn btn-sm btn-primary">
                            <i class="bi bi-search"></i>
                        </button>
                    </form>
                </div>

              
            </div>

            <div class="table-responsive">
                <table class="table table-sm table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Date</th>
                            <th>Reference</th>
                            <th>Supplier</th>
                            <th>Warehouse</th>
                            <th>Total</th>
                            <th>Paid</th>
                            <th>Due</th>
                            <th>Status</th>
                           
                            <th width="150">Action</th>
                           
                        </tr>
                    </thead>

                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($purchase->purchase_date->format('d M Y')); ?></td>

                            <td><b><?php echo e($purchase->reference_no); ?></b></td>

                            <td><?php echo e($purchase->supplier->name ?? 'N/A'); ?></td>

                            <td><?php echo e($purchase->warehouse->name ?? 'N/A'); ?></td>

                            <td>৳<?php echo e(number_format($purchase->total,2)); ?></td>

                            <td>৳<?php echo e(number_format($purchase->paid_amount,2)); ?></td>

                            <td>৳<?php echo e(number_format($purchase->due_amount,2)); ?></td>

                            <td>
                                <?php if($purchase->payment_status=='paid'): ?>
                                    <span class="badge bg-success">Paid</span>
                                <?php elseif($purchase->payment_status=='partial'): ?>
                                    <span class="badge bg-info">Partial</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Unpaid</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                
                                <a href="<?php echo e(route('purchases.show',$purchase)); ?>" class="btn btn-sm btn-info">
                                    <i class="bi bi-eye"></i>
                                </a>

                                <a href="<?php echo e(route('purchases.edit',$purchase)); ?>" class="btn btn-sm btn-warning">
                                    <i class="bi bi-pencil"></i>
                                </a>

                                <form action="<?php echo e(route('purchases.destroy',$purchase)); ?>" method="POST" 
                                      class="d-inline-block"
                                      onsubmit="return confirm('Delete this purchase?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                  
                                </form>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center text-muted py-4">
                                <i class="bi bi-inbox fs-1"></i>
                                <p>No purchases found</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-end mt-3">
                <?php echo e($purchases->links()); ?>

            </div>
        </div>
    </div>
      </div> 

    <!-- Footer Note -->
    <div class="row mt-4 mb-3">
        <div class="col-12">
            <p class="text-center text-muted small mb-0">
                Developed by Shifaul Hasan &copy; 2026
            </p>
        </div>
    </div>

</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/purchases/index.blade.php ENDPATH**/ ?>