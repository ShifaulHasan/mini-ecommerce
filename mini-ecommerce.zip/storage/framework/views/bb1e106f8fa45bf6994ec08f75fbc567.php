<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Account')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <style>
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: flex-start;
            justify-content: center;
            z-index: 9999;
            padding-top: 50px;
            overflow-y: auto;
        }
        .modal-container {
            background: white;
            border-radius: 6px;
            width: 90%;
            max-width: 620px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            margin-bottom: 50px;
        }
        .modal-header {
            padding: 16px 20px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f9fafb;
        }
        .modal-header h3 {
            margin: 0;
            font-size: 16px;
            font-weight: 600;
            color: #374151;
        }
        .close-btn {
            background: none;
            border: none;
            font-size: 22px;
            color: #9ca3af;
            cursor: pointer;
        }
        .close-btn:hover {
            color: #6b7280;
        }
        .modal-body {
            padding: 20px;
        }
        .form-notice {
            font-size: 13px;
            color: #6b7280;
            font-style: italic;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 18px;
        }
        .form-label {
            display: block;
            font-size: 13px;
            color: #374151;
            margin-bottom: 6px;
        }
        .required {
            color: #ef4444;
        }
        .optional {
            color: #9ca3af;
            font-size: 12px;
            font-style: italic;
        }
        .form-control {
            width: 100%;
            padding: 8px 12px;
            font-size: 14px;
            border: 1px solid #d1d5db;
            border-radius: 4px;
        }
        .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59,130,246,.1);
            outline: none;
        }
        .form-control.is-invalid {
            border-color: #ef4444;
        }
        .invalid-feedback {
            color: #ef4444;
            font-size: 12px;
            margin-top: 4px;
        }
        textarea.form-control {
            resize: vertical;
            min-height: 90px;
        }
        .number-input-wrapper {
            position: relative;
        }
        .number-spinner {
            position: absolute;
            right: 2px;
            top: 2px;
            bottom: 2px;
            display: flex;
            flex-direction: column;
            border-left: 1px solid #d1d5db;
        }
        .spinner-btn {
            flex: 1;
            border: none;
            background: transparent;
            cursor: pointer;
            font-size: 9px;
        }
        .spinner-btn:hover {
            background: #f3f4f6;
        }
        .modal-footer {
            padding: 14px 20px;
            border-top: 1px solid #e5e7eb;
            background: #f9fafb;
        }
        .btn-submit {
            padding: 7px 24px;
            border: none;
            border-radius: 4px;
            font-size: 13px;
            background: #8b5cf6;
            color: white;
            cursor: pointer;
        }
        .btn-submit:hover {
            background: #7c3aed;
        }
    </style>

    <div class="py-6">
        <div class="modal-overlay">
            <div class="modal-container">
                <!-- Header -->
                <div class="modal-header">
                    <h3>Edit Account</h3>
                    <button class="close-btn" onclick="window.location='<?php echo e(route('accounts.index')); ?>'">&times;</button>
                </div>

                <!-- Body -->
                <div class="modal-body">
                    <p class="form-notice">The field labels marked with * are required.</p>

                    <form action="<?php echo e(route('accounts.update', $account->id)); ?>" method="POST" id="accountForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Account No -->
                        <div class="form-group">
                            <label class="form-label">Account No <span class="required">*</span></label>
                            <input type="text" name="account_no"
                                   class="form-control <?php $__errorArgs = ['account_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('account_no', $account->account_no)); ?>" required>
                            <?php $__errorArgs = ['account_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Name -->
                        <div class="form-group">
                            <label class="form-label">Name <span class="required">*</span></label>
                            <input type="text" name="name"
                                   class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('name', $account->name)); ?>" required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Branch -->
                        <div class="form-group">
                            <label class="form-label">Branch <span class="optional">(Optional)</span></label>
                            <input type="text" name="branch"
                                   class="form-control <?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('branch', $account->branch)); ?>">
                            <?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Swift Code -->
                        <div class="form-group">
                            <label class="form-label">Swift Code <span class="optional">(Optional)</span></label>
                            <input type="text" name="swift_code"
                                   class="form-control <?php $__errorArgs = ['swift_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('swift_code', $account->swift_code)); ?>">
                            <?php $__errorArgs = ['swift_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Initial Balance -->
                        <div class="form-group">
                            <label class="form-label">Initial Balance</label>
                            <div class="number-input-wrapper">
                                <input type="number" name="initial_balance"
                                       class="form-control <?php $__errorArgs = ['initial_balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('initial_balance', $account->initial_balance)); ?>"
                                       step="0.01" style="padding-right:45px;">
                                <div class="number-spinner">
                                    <button type="button" class="spinner-btn" onclick="inc()">▲</button>
                                    <button type="button" class="spinner-btn" onclick="dec()">▼</button>
                                </div>
                            </div>
                            <?php $__errorArgs = ['initial_balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Note -->
                        <div class="form-group">
                            <label class="form-label">Note</label>
                            <textarea name="note"
                                      class="form-control <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('note', $account->note)); ?></textarea>
                            <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </form>
                </div>

                <!-- Footer -->
                <div class="modal-footer">
                    <button type="submit" form="accountForm" class="btn-submit">Update</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function inc() {
            const i = document.querySelector('[name="initial_balance"]');
            i.value = (parseFloat(i.value || 0) + 0.01).toFixed(2);
        }
        function dec() {
            const i = document.querySelector('[name="initial_balance"]');
            i.value = Math.max(0, parseFloat(i.value || 0) - 0.01).toFixed(2);
        }

        document.addEventListener('keydown', e => {
            if (e.key === 'Escape') window.location='<?php echo e(route('accounts.index')); ?>';
        });

        document.querySelector('.modal-overlay')
            .addEventListener('click', e => {
                if (e.target === e.currentTarget)
                    window.location='<?php echo e(route('accounts.index')); ?>';
            });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/accounts/edit.blade.php ENDPATH**/ ?>