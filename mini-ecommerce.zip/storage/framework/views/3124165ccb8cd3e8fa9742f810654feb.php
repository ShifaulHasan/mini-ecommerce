<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div>
            <h2 class="mb-0">Customer Details</h2>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('customers.index')); ?>">Customers</a>
                    </li>
                    <li class="breadcrumb-item active">
                        <?php echo e($customer->name); ?>

                    </li>
                </ol>
            </nav>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="container-fluid">
        <div class="d-flex justify-content-end mb-4">
            <a href="<?php echo e(route('customers.edit', $customer)); ?>" class="btn btn-primary me-2">
                <i class="fas fa-edit"></i> Edit Customer
            </a>
            <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to List
            </a>
        </div>

        <div class="row">
            <!-- Customer Info -->
            <div class="col-md-4">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-user"></i> Customer Information
                        </h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-borderless mb-0">
                            <tr>
                                <td class="text-muted"><strong>Customer Code:</strong></td>
                                <td><?php echo e($customer->customer_code); ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted"><strong>Name:</strong></td>
                                <td><?php echo e($customer->name); ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted"><strong>Email:</strong></td>
                                <td><?php echo e($customer->email ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted"><strong>Phone:</strong></td>
                                <td><?php echo e($customer->phone); ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted"><strong>Company:</strong></td>
                                <td><?php echo e($customer->company_name ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted"><strong>Status:</strong></td>
                                <td>
                                    <?php if($customer->is_active): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="card shadow-sm">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-map-marker-alt"></i> Address
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php echo e($customer->address ?? 'No address provided'); ?>

                    </div>
                </div>
            </div>

            <!-- Financial Summary -->
            <div class="col-md-8">
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card shadow-sm border-left-primary">
                            <div class="card-body">
                                <div class="text-uppercase text-primary small">
                                    Total Sales
                                </div>
                                <div class="h5">
                                    ৳<?php echo e(number_format($totalSales, 2)); ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card shadow-sm border-left-success">
                            <div class="card-body">
                                <div class="text-uppercase text-success small">
                                    Sales Count
                                </div>
                                <div class="h5">
                                    <?php echo e($salesCount); ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card shadow-sm border-left-warning">
                            <div class="card-body">
                                <div class="text-uppercase text-warning small">
                                    Total Due
                                </div>
                                <div class="h5">
                                    ৳<?php echo e(number_format($customer->total_due, 2)); ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- <div class="col-md-3">
                        <div class="card shadow-sm border-left-info">
                            <div class="card-body">
                                <div class="text-uppercase text-info small">
                                    Deposited Balance
                                </div>
                                <div class="h5">
                                    ৳<?php echo e(number_format($customer->deposited_balance ?? 0, 2)); ?>

                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        .border-left-primary { border-left: 4px solid #4e73df; }
        .border-left-success { border-left: 4px solid #1cc88a; }
        .border-left-warning { border-left: 4px solid #f6c23e; }
        .border-left-info { border-left: 4px solid #36b9cc; }
    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/customers/show.blade.php ENDPATH**/ ?>