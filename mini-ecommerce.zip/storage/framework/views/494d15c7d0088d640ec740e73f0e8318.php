<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 fw-semibold text-dark">Dashboard</h2>
     <?php $__env->endSlot(); ?>

    <div class="container-fluid">

        <!-- ======== SUMMARY CARDS ======== -->
        <div class="row">

            <div class="col-md-3">
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body text-center">
                        <h6 class="fw-bold text-muted">Total Sale</h6>
                        <h3 class="fw-bold text-primary"><?php echo e(number_format($totalSale ?? 0,2)); ?></h3>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body text-center">
                        <h6 class="fw-bold text-muted">Total Payment</h6>
                        <h3 class="fw-bold text-success"><?php echo e(number_format($totalPayment ?? 0,2)); ?></h3>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body text-center">
                        <h6 class="fw-bold text-muted">Total Due</h6>
                        <h3 class="fw-bold text-danger"><?php echo e(number_format($totalDue ?? 0,2)); ?></h3>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-body text-center">
                        <h6 class="fw-bold text-muted">This Month Sale</h6>
                        <h3 class="fw-bold text-info"><?php echo e(number_format($monthlySale ?? 0,2)); ?></h3>
                    </div>
                </div>
            </div>

        </div>

        <!-- ======== CASH FLOW + DONUT CHART ======== -->
        <div class="row mt-4">

            <div class="col-md-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header fw-bold">Cash Flow</div>
                    <div class="card-body">
                        <canvas id="cashFlowChart" height="130"></canvas>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm border-0">
                    <div class="card-header fw-bold">Report (<?php echo e(now()->format('F Y')); ?>)</div>
                    <div class="card-body">
                        <canvas id="donutChart" height="200"></canvas>
                    </div>
                </div>
            </div>

        </div>

        <!-- ======== PIE CHART + SALES OVERVIEW ======== -->
        <div class="row mt-4">
            
            <div class="col-md-4">
                <div class="card shadow-sm border-0">
                    <div class="card-header fw-bold">Sales by Category</div>
                    <div class="card-body">
                        <canvas id="pieChart" height="200"></canvas>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header fw-bold">Monthly Sales Overview</div>
                    <div class="card-body">
                        <canvas id="barChart" height="130"></canvas>
                    </div>
                </div>
            </div>

        </div>

        <!-- ======== BEST SELL PRODUCT ======== -->
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card shadow-sm border-0">
                    <div class="card-header fw-bold">Best Sale Product (This Month)</div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Qty</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $bestProducts ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->qty); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card shadow-sm border-0">
                    <div class="card-header fw-bold">Recent Transactions</div>
                    <div class="card-body">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Ref</th>
                                    <th>Customer</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $recent ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($row->date); ?></td>
                                        <td><?php echo e($row->ref); ?></td>
                                        <td><?php echo e($row->customer); ?></td>
                                        <td><?php echo e($row->total); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- CHART JS -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        // ======= CASH FLOW CHART =======
        const ctx = document.getElementById('cashFlowChart');
        const months = <?php echo json_encode($months ?? []); ?>;
        const paymentReceived = <?php echo json_encode($paymentReceived ?? []); ?>;
        const paymentSent = <?php echo json_encode($paymentSent ?? []); ?>;

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: months,
                datasets: [
                    {
                        label: 'Payment Received',
                        data: paymentReceived,
                        borderColor: 'rgb(75, 192, 192)',
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderWidth: 2,
                        tension: 0.4
                    },
                    {
                        label: 'Payment Sent',
                        data: paymentSent,
                        borderColor: 'rgb(255, 99, 132)',
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderWidth: 2,
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });

        // ======= DONUT CHART =======
        const donut = document.getElementById('donutChart');
        const donutData = <?php echo json_encode($donutData ?? [0,0,0]); ?>;

        new Chart(donut, {
            type: 'doughnut',
            data: {
                labels: ['Purchase', 'Revenue', 'Expense'],
                datasets: [{
                    data: donutData,
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(54, 162, 235)',
                        'rgb(255, 205, 86)'
                    ],
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });

        // ======= PIE CHART (NEW) =======
        const pie = document.getElementById('pieChart');
        const categoryLabels = <?php echo json_encode($categoryLabels ?? ['Electronics', 'Clothing', 'Food', 'Others']); ?>;
        const categoryData = <?php echo json_encode($categoryData ?? [30, 25, 20, 25]); ?>;

        new Chart(pie, {
            type: 'pie',
            data: {
                labels: categoryLabels,
                datasets: [{
                    data: categoryData,
                    backgroundColor: [
                        'rgb(54, 162, 235)',
                        'rgb(255, 99, 132)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)'
                    ],
                    hoverOffset: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += context.parsed + '%';
                                return label;
                            }
                        }
                    }
                }
            }
        });

        // ======= BAR CHART (BONUS) =======
        const bar = document.getElementById('barChart');
        const monthlySalesData = <?php echo json_encode($monthlySales ?? []); ?>;

        new Chart(bar, {
            type: 'bar',
            data: {
                labels: months,
                datasets: [{
                    label: 'Monthly Sales',
                    data: monthlySalesData,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgb(54, 162, 235)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/dashboard.blade.php ENDPATH**/ ?>