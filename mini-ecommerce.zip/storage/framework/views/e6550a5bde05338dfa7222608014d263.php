<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 fw-semibold text-dark">Payroll Details</h2>
     <?php $__env->endSlot(); ?>

    <div class="container-fluid py-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h5 class="border-bottom pb-2 mb-3">Payroll Information</h5>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Reference:</div>
                            <div class="col-md-7"><?php echo e($payroll->payroll_reference); ?></div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Payment Date:</div>
                            <div class="col-md-7"><?php echo e($payroll->payment_date->format('F d, Y')); ?></div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Employee:</div>
                            <div class="col-md-7"><?php echo e($payroll->employee->name ?? 'N/A'); ?></div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Staff ID:</div>
                            <div class="col-md-7"><?php echo e($payroll->employee->staff_id ?? 'N/A'); ?></div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Account:</div>
                            <div class="col-md-7"><?php echo e($payroll->account->name ?? 'N/A'); ?></div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Account Number:</div>
                            <div class="col-md-7"><?php echo e($payroll->account->account_no ?? 'N/A'); ?></div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Amount:</div>
                            <div class="col-md-7">
                                <span class="badge bg-success fs-6"><?php echo e(number_format($payroll->amount, 2)); ?></span>
                            </div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Payment Method:</div>
                            <div class="col-md-7">
                                <span class="badge bg-info"><?php echo e($payroll->payment_method); ?></span>
                            </div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Note:</div>
                            <div class="col-md-7"><?php echo e($payroll->note ?? 'N/A'); ?></div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <h5 class="border-bottom pb-2 mb-3">Additional Information</h5>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Created By:</div>
                            <div class="col-md-7"><?php echo e($payroll->creator->name ?? 'System'); ?></div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Created At:</div>
                            <div class="col-md-7"><?php echo e($payroll->created_at->format('F d, Y h:i A')); ?></div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Last Updated:</div>
                            <div class="col-md-7"><?php echo e($payroll->updated_at->format('F d, Y h:i A')); ?></div>
                        </div>

                        <?php if($payroll->transaction): ?>
                        <h5 class="border-bottom pb-2 mb-3 mt-4">Transaction Details</h5>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Transaction Type:</div>
                            <div class="col-md-7">
                                <span class="badge bg-danger"><?php echo e(strtoupper($payroll->transaction->transaction_type)); ?></span>
                            </div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Balance Before:</div>
                            <div class="col-md-7"><?php echo e(number_format($payroll->transaction->balance_before, 2)); ?></div>
                        </div>
                        
                        <div class="row mb-2">
                            <div class="col-md-5 fw-bold">Balance After:</div>
                            <div class="col-md-7"><?php echo e(number_format($payroll->transaction->balance_after, 2)); ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mt-4">
                    <a href="<?php echo e(route('payrolls.edit', $payroll)); ?>" class="btn btn-warning">
                        <i class="bi bi-pencil"></i> Edit
                    </a>
                    <a href="<?php echo e(route('payrolls.index')); ?>" class="btn btn-secondary">
                        <i class="bi bi-arrow-left"></i> Back to List
                    </a>
                    <form action="<?php echo e(route('payrolls.destroy', $payroll)); ?>" 
                          method="POST" 
                          class="d-inline"
                          onsubmit="return confirm('Are you sure you want to delete this payroll?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">
                            <i class="bi bi-trash"></i> Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/payrolls/show.blade.php ENDPATH**/ ?>