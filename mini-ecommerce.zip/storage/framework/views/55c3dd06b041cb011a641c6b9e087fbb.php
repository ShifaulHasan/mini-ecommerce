<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="h5 fw-semibold mb-0">
                <i class="bi bi-credit-card"></i> Payment Report
            </h2>
            <button onclick="window.print()" class="btn btn-primary btn-sm">
                <i class="bi bi-printer"></i> Print
            </button>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <!-- Filter Form -->
                        <form method="GET" action="<?php echo e(route('reports.payments')); ?>" class="mb-4">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="form-label">Start Date</label>
                                    <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">End Date</label>
                                    <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Account</label>
                                    <select name="account_id" class="form-select">
                                        <option value="">All Accounts</option>
                                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($account->id); ?>" <?php echo e(request('account_id') == $account->id ? 'selected' : ''); ?>>
                                                <?php echo e($account->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">Transaction Type</label>
                                    <select name="transaction_type" class="form-select">
                                        <option value="">All Types</option>
                                        <option value="credit" <?php echo e(request('transaction_type') == 'credit' ? 'selected' : ''); ?>>Credit</option>
                                        <option value="debit" <?php echo e(request('transaction_type') == 'debit' ? 'selected' : ''); ?>>Debit</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-funnel"></i> Filter
                                    </button>
                                    <a href="<?php echo e(route('reports.payments')); ?>" class="btn btn-secondary">
                                        <i class="bi bi-arrow-clockwise"></i> Reset
                                    </a>
                                </div>
                            </div>
                        </form>

                        <!-- Summary Cards -->
                        <div class="row mb-4">
                            <div class="col-md-4">
                                <div class="card bg-success text-white">
                                    <div class="card-body">
                                        <h6 class="card-subtitle mb-2 opacity-75">Total Credit</h6>
                                        <h3 class="card-title mb-0">৳<?php echo e(number_format($totals['total_credit'], 2)); ?></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card bg-danger text-white">
                                    <div class="card-body">
                                        <h6 class="card-subtitle mb-2 opacity-75">Total Debit</h6>
                                        <h3 class="card-title mb-0">৳<?php echo e(number_format($totals['total_debit'], 2)); ?></h3>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card bg-info text-white">
                                    <div class="card-body">
                                        <h6 class="card-subtitle mb-2 opacity-75">Net Balance</h6>
                                        <h3 class="card-title mb-0">৳<?php echo e(number_format($totals['net_balance'], 2)); ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Report Table -->
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered align-middle">
                                <thead class="table-dark">
                                    <tr>
                                        <th>SL</th>
                                        <th>Date</th>
                                        <th>Account</th>
                                        <th>Reference Type</th>
                                        <th>Description</th>
                                        <th>Payment Method</th>
                                        <th class="text-center">Type</th>
                                        <th class="text-end">Amount</th>
                                        <th>Created By</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime($payment->transaction_date))); ?></td>
                                        <td><?php echo e($payment->account_name); ?></td>
                                        <td>
                                            <span class="badge bg-secondary">
                                                <?php echo e(ucfirst($payment->reference_type ?? 'N/A')); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e($payment->description); ?></td>
                                        <td><?php echo e(ucfirst(str_replace('_', ' ', $payment->payment_method ?? 'N/A'))); ?></td>
                                        <td class="text-center">
                                            <span class="badge bg-<?php echo e($payment->transaction_type == 'credit' ? 'success' : 'danger'); ?>">
                                                <i class="bi bi-<?php echo e($payment->transaction_type == 'credit' ? 'arrow-down-circle' : 'arrow-up-circle'); ?>"></i>
                                                <?php echo e(ucfirst($payment->transaction_type)); ?>

                                            </span>
                                        </td>
                                        <td class="text-end <?php echo e($payment->transaction_type == 'credit' ? 'text-success' : 'text-danger'); ?>">
                                            <strong><?php echo e($payment->transaction_type == 'credit' ? '+' : '-'); ?>৳<?php echo e(number_format($payment->amount, 2)); ?></strong>
                                        </td>
                                        <td><?php echo e($payment->created_by_name ?? 'System'); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="9" class="text-center text-muted py-4">
                                            <i class="bi bi-inbox fs-1"></i>
                                            <p class="mb-0">No payments found</p>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                                <?php if(count($payments) > 0): ?>
                                <tfoot class="table-secondary">
                                    <tr class="fw-bold">
                                        <td colspan="7" class="text-end">Summary:</td>
                                        <td class="text-end">
                                            <div class="text-success">Credit: ৳<?php echo e(number_format($totals['total_credit'], 2)); ?></div>
                                            <div class="text-danger">Debit: ৳<?php echo e(number_format($totals['total_debit'], 2)); ?></div>
                                            <div class="text-info border-top pt-1">Balance: ৳<?php echo e(number_format($totals['net_balance'], 2)); ?></div>
                                        </td>
                                        <td></td>
                                    </tr>
                                </tfoot>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        @media print {
            .btn, form, .navbar, .sidebar { display: none !important; }
            .card { border: none !important; box-shadow: none !important; }
        }
    </style>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/reports/payments.blade.php ENDPATH**/ ?>