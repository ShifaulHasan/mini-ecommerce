<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="h4 fw-semibold mb-0">Edit Purchase</h2>
            <a href="<?php echo e(route('purchases.index')); ?>" class="btn btn-secondary btn-sm">
                <i class="bi bi-arrow-left"></i> Back to List
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <form action="<?php echo e(route('purchases.update', $purchase)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <!-- Purchase Information -->
        <div class="card mb-3">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Purchase Information</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Reference Number</label>
                        <input type="text" class="form-control" value="<?php echo e($purchase->reference_no); ?>" readonly>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Purchase Date <span class="text-danger">*</span></label>
                        <input type="date" name="purchase_date" 
                               class="form-control <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('purchase_date', $purchase->purchase_date->format('Y-m-d'))); ?>" required>
                        <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Supplier <span class="text-danger">*</span></label>
                        <select name="supplier_id" class="form-select <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="">Select Supplier</option>
                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    // Build the current purchase's supplier ID for comparison
                                    $currentSupplierCombinedId = $purchase->supplier_type . '_' . $purchase->supplier_id;
                                ?>
                                <option value="<?php echo e($supplier->id); ?>" 
                                        <?php echo e(old('supplier_id', $currentSupplierCombinedId) == $supplier->id ? 'selected' : ''); ?>>
                                    <?php echo e($supplier->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Warehouse <span class="text-danger">*</span></label>
                        <select name="warehouse_id" class="form-select" required>
                            <option value="">Select Warehouse</option>
                            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($warehouse->id); ?>" 
                                    <?php echo e(old('warehouse_id', $purchase->warehouse_id) == $warehouse->id ? 'selected' : ''); ?>>
                                <?php echo e($warehouse->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Purchase Status</label>
                        <select name="purchase_status" class="form-select">
                            <option value="pending" <?php echo e(old('purchase_status', $purchase->purchase_status) == 'pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="received" <?php echo e(old('purchase_status', $purchase->purchase_status) == 'received' ? 'selected' : ''); ?>>Received</option>
                            <option value="cancelled" <?php echo e(old('purchase_status', $purchase->purchase_status) == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Paid Amount</label>
                        <input type="number" name="paid_amount" class="form-control" 
                               step="0.01" min="0" max="<?php echo e($purchase->grand_total); ?>"
                               value="<?php echo e(old('paid_amount', $purchase->paid_amount ?? 0)); ?>">
                        <small class="text-muted">Max: <?php echo e(number_format($purchase->grand_total, 2)); ?></small>
                    </div>
                </div>

                <div class="mt-3">
                    <label class="form-label">Notes</label>
                    <textarea name="notes" class="form-control" rows="3"><?php echo e(old('notes', $purchase->notes)); ?></textarea>
                </div>
            </div>
        </div>

        <!-- Purchase Items -->
        <div class="card mb-3">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0">Purchase Items</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>Product</th>
                                <th width="100">Quantity</th>
                                <th width="150">Cost Price</th>
                                <th width="150">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $purchase->items ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <?php echo e($item->product->name ?? 'N/A'); ?>

                                    <?php if($item->product->sku): ?>
                                        <br><small class="text-muted">SKU: <?php echo e($item->product->sku); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo e($item->quantity); ?></td>
                                <td class="text-end"><?php echo e(number_format($item->cost_price, 2)); ?></td>
                                <td class="text-end"><?php echo e(number_format($item->subtotal, 2)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted">No items found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot class="table-light">
                            <tr>
                                <td colspan="3" class="text-end"><strong>Subtotal:</strong></td>
                                <td class="text-end"><strong><?php echo e(number_format($purchase->subtotal ?? 0, 2)); ?></strong></td>
                            </tr>
                            <?php if($purchase->tax_amount > 0): ?>
                            <tr>
                                <td colspan="3" class="text-end">Tax (<?php echo e($purchase->tax_percentage); ?>%):</td>
                                <td class="text-end"><?php echo e(number_format($purchase->tax_amount, 2)); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($purchase->discount_amount > 0): ?>
                            <tr>
                                <td colspan="3" class="text-end">Discount:</td>
                                <td class="text-end text-danger">-<?php echo e(number_format($purchase->discount_amount, 2)); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php if($purchase->shipping_cost > 0): ?>
                            <tr>
                                <td colspan="3" class="text-end">Shipping:</td>
                                <td class="text-end"><?php echo e(number_format($purchase->shipping_cost, 2)); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr class="table-primary">
                                <td colspan="3" class="text-end"><strong>Grand Total:</strong></td>
                                <td class="text-end"><strong><?php echo e(number_format($purchase->grand_total ?? 0, 2)); ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <div class="alert alert-info mb-0">
                    <i class="bi bi-info-circle"></i> To modify purchase items, quantities, or prices, please delete this purchase and create a new one.
                </div>
            </div>
        </div>

        <!-- Payment Summary -->
        <div class="card mb-3">
            <div class="card-header bg-warning">
                <h6 class="mb-0">Payment Summary</h6>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="d-flex justify-content-between">
                            <span>Grand Total:</span>
                            <strong><?php echo e(number_format($purchase->grand_total ?? 0, 2)); ?></strong>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex justify-content-between">
                            <span>Paid Amount:</span>
                            <strong class="text-success"><?php echo e(number_format($purchase->paid_amount ?? 0, 2)); ?></strong>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex justify-content-between">
                            <span>Due Amount:</span>
                            <strong class="text-danger"><?php echo e(number_format($purchase->due_amount ?? 0, 2)); ?></strong>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="d-flex justify-content-between align-items-center">
                    <span>Payment Status:</span>
                    <span class="badge 
                        <?php if($purchase->payment_status == 'paid'): ?> bg-success
                        <?php elseif($purchase->payment_status == 'partial'): ?> bg-warning
                        <?php else: ?> bg-danger
                        <?php endif; ?>">
                        <?php echo e(ucfirst($purchase->payment_status ?? 'unpaid')); ?>

                    </span>
                </div>
            </div>
        </div>

        <!-- Buttons -->
        <div class="mb-3">
            <button type="submit" class="btn btn-primary">
                <i class="bi bi-check-circle"></i> Update Purchase
            </button>
            <a href="<?php echo e(route('purchases.index')); ?>" class="btn btn-secondary">
                <i class="bi bi-x-circle"></i> Cancel
            </a>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/purchases/edit.blade.php ENDPATH**/ ?>