
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 fw-semibold text-dark">
            
            <i class="bi bi-plus-circle"></i> Add Stock Adjustment
          
        </h2>

     <?php $__env->endSlot(); ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="<?php echo e(route('adjustments.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left"></i> Back to List
        </a>
    </div>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle"></i> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="bi bi-sliders"></i> Adjustment Details</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('adjustments.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <!-- Warehouse -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold"><i class="bi bi-building"></i> Select Warehouse <span class="text-danger">*</span></label>
                                <select name="warehouse_id" id="warehouseSelect" class="form-select <?php $__errorArgs = ['warehouse_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required onchange="updateStock()">
                                    <option value="">-- Choose Warehouse --</option>
                                    <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($warehouse->id); ?>" <?php echo e(old('warehouse_id') == $warehouse->id ? 'selected' : ''); ?>>
                                            <?php echo e($warehouse->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['warehouse_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Product -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold"><i class="bi bi-box"></i> Select Product <span class="text-danger">*</span></label>
                                <select name="product_id" id="productSelect" class="form-select <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required onchange="updateStock()">
                                    <option value="">-- Choose Product --</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>" <?php echo e(old('product_id') == $product->id ? 'selected' : ''); ?>>
                                            <?php echo e($product->name); ?> (<?php echo e($product->product_code ?? 'N/A'); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Stock Info -->
                            <div class="col-12">
                                <div class="alert alert-info d-none" id="stockInfo">
                                    <div class="row align-items-center">
                                        <div class="col-md-4">
                                            <strong>Product:</strong> <p class="mb-0" id="productName">-</p>
                                        </div>
                                        <div class="col-md-4">
                                            <strong>Product Code:</strong> <p class="mb-0" id="productCode">-</p>
                                        </div>
                                        <div class="col-md-4">
                                            <strong>Current Stock:</strong>
                                            <p class="mb-0 fs-4 text-primary">
                                                <i class="bi bi-box-seam"></i> <span id="currentStock">0</span> units
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Adjustment Type -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold"><i class="bi bi-arrow-repeat"></i> Adjustment Type <span class="text-danger">*</span></label>
                                <select name="adjustment_type" class="form-select <?php $__errorArgs = ['adjustment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value="">-- Select Type --</option>
                                    <option value="addition" <?php echo e(old('adjustment_type') == 'addition' ? 'selected' : ''); ?>>➕ Addition (Increase Stock)</option>
                                    <option value="subtraction" <?php echo e(old('adjustment_type') == 'subtraction' ? 'selected' : ''); ?>>➖ Subtraction (Decrease Stock)</option>
                                </select>
                                <?php $__errorArgs = ['adjustment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Quantity -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold"><i class="bi bi-123"></i> Adjustment Quantity <span class="text-danger">*</span></label>
                                <input type="number" name="quantity" class="form-control form-control-lg <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('quantity')); ?>" min="1" placeholder="Enter quantity to adjust" required>
                                <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <!-- Reason -->
                            <div class="col-12">
                                <label class="form-label fw-bold"><i class="bi bi-chat-left-text"></i> Reason for Adjustment</label>
                                <textarea name="reason" class="form-control" rows="3" placeholder="e.g., Damaged goods, Stock correction, Returns..."><?php echo e(old('reason')); ?></textarea>
                                <small class="text-muted"><i class="bi bi-info-circle"></i> Optional: Provide details for audit trail</small>
                            </div>
                        </div>

                        <hr class="my-4">

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary btn-lg"><i class="bi bi-check-circle"></i> Submit Adjustment</button>
                            <a href="<?php echo e(route('adjustments.index')); ?>" class="btn btn-secondary btn-lg"><i class="bi bi-x-circle"></i> Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Help Guide -->
        <div class="col-lg-4">
            <div class="card shadow-sm border-0 bg-light">
                <div class="card-body">
                    <h6 class="card-title text-primary"><i class="bi bi-info-circle-fill"></i> Adjustment Guide</h6>
                    <hr>
                    <div class="mb-3">
                        <h6 class="text-success"><i class="bi bi-plus-circle-fill"></i> Addition (Increase)</h6>
                        <p class="small">Use when you need to add stock:</p>
                        <ul class="small">
                            <li>Found extra inventory during count</li>
                            <li>Correcting undercount errors</li>
                            <li>Customer returns</li>
                            <li>Manual stock entry</li>
                        </ul>
                    </div>

                    <div class="mb-3">
                        <h6 class="text-danger"><i class="bi bi-dash-circle-fill"></i> Subtraction (Decrease)</h6>
                        <p class="small">Use when you need to reduce stock:</p>
                        <ul class="small">
                            <li>Damaged or expired items</li>
                            <li>Theft or loss</li>
                            <li>Correcting overcount errors</li>
                            <li>Sample or promotional usage</li>
                        </ul>
                    </div>

                    <div class="alert alert-warning small"><i class="bi bi-exclamation-triangle-fill"></i> <strong>Important:</strong> Adjustments are permanent and immediately affect inventory levels.</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function updateStock() {
            const warehouseId = document.getElementById('warehouseSelect').value;
            const productId = document.getElementById('productSelect').value;
            const stockInfo = document.getElementById('stockInfo');

            if (warehouseId && productId) {
                fetch(`<?php echo e(route('adjustments.get-stock')); ?>?warehouse_id=${warehouseId}&product_id=${productId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            document.getElementById('currentStock').textContent = data.stock;
                            document.getElementById('productName').textContent = data.product_name;
                            document.getElementById('productCode').textContent = data.product_code;
                            stockInfo.classList.remove('d-none');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        stockInfo.classList.add('d-none');
                    });
            } else {
                stockInfo.classList.add('d-none');
            }
        }
    </script>

        </div> 

    <!-- Footer Note -->
    <div class="row mt-4 mb-3">
        <div class="col-12">
            <p class="text-center text-muted small mb-0">
                Developed by Shifaul Hasan &copy; 2026
            </p>
        </div>
    </div>

</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/adjustments/create.blade.php ENDPATH**/ ?>