<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="h5 fw-semibold mb-0">
                <i class="bi bi-receipt"></i> Sale Details
            </h2>
            <a href="<?php echo e(route('sales.index')); ?>" class="btn btn-sm btn-secondary">
                <i class="bi bi-arrow-left"></i> Back to List
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-md-8">
            <!-- Sale Information -->
            <div class="card mb-3">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Sale Information</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <strong>Reference No:</strong>
                            <p><?php echo e($sale->reference_no); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong>Date:</strong>
                            <p><?php echo e($sale->sale_date ? $sale->sale_date->format('d M Y') : 'N/A'); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong>Customer:</strong>
                            <p><?php echo e(optional($sale->customer)->name ?? 'Walk-in Customer'); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong>Biller:</strong>
                            <p><?php echo e(optional($sale->biller)->name ?? 'N/A'); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong>Warehouse:</strong>
                            <p><?php echo e(optional($sale->warehouse)->name ?? 'N/A'); ?></p>
                        </div>
                        <div class="col-md-6 mb-3">
                            <strong>Status:</strong>
                            <p>
                                <?php if($sale->status === 'completed'): ?>
                                <span class="badge bg-success">Completed</span>
                                <?php else: ?>
                                <span class="badge bg-warning">Pending</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <?php if($sale->notes): ?>
                        <div class="col-12 mb-3">
                            <strong>Notes:</strong>
                            <p><?php echo e($sale->notes); ?></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Sale Items -->
            <div class="card">
                <div class="card-header bg-secondary text-white">
                    <h5 class="mb-0">Sale Items</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Unit Price</th>
                                    <th>Discount</th>
                                    <th>Tax</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $sale->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(optional($item->product)->name ?? 'N/A'); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td>$<?php echo e(number_format($item->unit_price, 2)); ?></td>
                                    <td>$<?php echo e(number_format($item->discount ?? 0, 2)); ?></td>
                                    <td>$<?php echo e(number_format($item->tax ?? 0, 2)); ?></td>
                                    <td>$<?php echo e(number_format(($item->quantity * $item->unit_price) - ($item->discount ?? 0) + ($item->tax ?? 0), 2)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">No items found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <!-- Payment Summary -->
            <div class="card mb-3">
                <div class="card-header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                    <h5 class="mb-0">Payment Summary</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-2">
                        <span>Subtotal:</span>
                        <strong>$<?php echo e(number_format(($sale->grand_total ?? 0) - ($sale->tax_amount ?? 0) + ($sale->discount_amount ?? 0), 2)); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Tax (<?php echo e($sale->tax_percentage ?? 0); ?>%):</span>
                        <strong>$<?php echo e(number_format($sale->tax_amount ?? 0, 2)); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Discount:</span>
                        <strong>-$<?php echo e(number_format($sale->discount_amount ?? 0, 2)); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Shipping:</span>
                        <strong>$<?php echo e(number_format($sale->shipping_cost ?? 0, 2)); ?></strong>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between mb-3">
                        <strong>Grand Total:</strong>
                        <strong class="text-primary" style="font-size: 20px;">$<?php echo e(number_format($sale->grand_total ?? 0, 2)); ?></strong>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Paid Amount:</span>
                        <strong class="text-success">$<?php echo e(number_format($sale->paid_amount ?? 0, 2)); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Due Amount:</span>
                        <strong class="text-danger">$<?php echo e(number_format($sale->due_amount ?? 0, 2)); ?></strong>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Payment Method:</span>
                        <strong><?php echo e(ucfirst($sale->payment_method ?? 'N/A')); ?></strong>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Payment Status:</span>
                        <span>
                            <?php if($sale->payment_status === 'paid'): ?>
                            <span class="badge bg-success">Paid</span>
                            <?php elseif($sale->payment_status === 'partial'): ?>
                            <span class="badge bg-warning">Partial</span>
                            <?php else: ?>
                            <span class="badge bg-danger">Unpaid</span>
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Actions -->
            <div class="card">
                <div class="card-body">
                    <a href="<?php echo e(route('sales.edit', $sale->id)); ?>" class="btn btn-warning w-100 mb-2">
                        <i class="bi bi-pencil"></i> Edit Sale
                    </a>
                    <form action="<?php echo e(route('sales.destroy', $sale->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger w-100">
                            <i class="bi bi-trash"></i> Delete Sale
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/sales/show.blade.php ENDPATH**/ ?>