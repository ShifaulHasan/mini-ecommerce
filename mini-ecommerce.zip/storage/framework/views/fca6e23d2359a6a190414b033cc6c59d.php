<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="d-flex justify-content-between align-items-center">
            <h2 class="h4 fw-semibold mb-0">Purchase Details</h2>
            <div class="d-flex gap-2">
                <button onclick="window.print()" class="btn btn-sm btn-secondary">
                    <i class="bi bi-printer"></i> Print
                </button>
                <a href="<?php echo e(route('purchases.index')); ?>" class="btn btn-sm btn-primary">
                    <i class="bi bi-arrow-left"></i> Back to List
                </a>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="row">
        <div class="col-md-8">

            <!-- Purchase Information -->
            <div class="card mb-3">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Purchase Information</h5>
                </div>
                <div class="card-body">

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Reference Number:</strong>
                            <p><?php echo e($purchase->reference_no); ?></p>
                        </div>
                        <div class="col-md-6">
                            <strong>Purchase Date:</strong>
                            <p><?php echo e($purchase->purchase_date->format('d M Y')); ?></p>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <strong>Supplier:</strong>
                            <p><?php echo e($purchase->supplier->name ?? 'N/A'); ?></p>
                        </div>
                        <div class="col-md-6">
                            <strong>Warehouse:</strong>
                            <p><?php echo e($purchase->warehouse->name ?? 'N/A'); ?></p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <strong>Status:</strong>
                            <p>
                                <span class="badge bg-<?php echo e($purchase->purchase_status === 'received' ? 'success' : ($purchase->purchase_status === 'pending' ? 'warning' : 'danger')); ?>">
                                    <?php echo e(ucfirst($purchase->purchase_status)); ?>

                                </span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <strong>Payment Status:</strong>
                            <p>
                                <span class="badge bg-<?php echo e($purchase->payment_status === 'paid' ? 'success' : ($purchase->payment_status === 'partial' ? 'info' : 'danger')); ?>">
                                    <?php echo e(ucfirst($purchase->payment_status)); ?>

                                </span>
                            </p>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Purchase Items -->
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">Purchase Items</h5>
                </div>
                <div class="card-body">

                    <div class="table-responsive">
                        <table class="table table-bordered table-sm">
                            <thead class="table-light">
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Net Price</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->product->name ?? 'N/A'); ?></td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e(number_format($item->net_unit_cost,2)); ?></td>
                                    <td><?php echo e(number_format($item->subtotal,2)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr class="table-light">
                                    <td colspan="3" class="text-end"><strong>Total:</strong></td>
                                    <td><strong><?php echo e(number_format($purchase->total,2)); ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                </div>
            </div>

        </div>

        <!-- Payment Summary Sidebar -->
        <div class="col-md-4">

            <div class="card mb-3">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">Payment Summary</h5>
                </div>
                <div class="card-body">

                    <div class="d-flex justify-content-between mb-2">
                        <span>Total:</span>
                        <strong><?php echo e(number_format($purchase->total, 2)); ?></strong>
                    </div>

                    <div class="d-flex justify-content-between mb-2">
                        <span>Paid:</span>
                        <strong class="text-success"><?php echo e(number_format($purchase->paid_amount, 2)); ?></strong>
                    </div>

                    <div class="d-flex justify-content-between">
                        <span>Due:</span>
                        <strong class="text-danger"><?php echo e(number_format($purchase->total - $purchase->paid_amount, 2)); ?></strong>
                    </div>

                </div>
            </div>

            <?php if($purchase->notes): ?>
            <div class="card mb-3">
                <div class="card-header">
                    <h6 class="mb-0">Notes</h6>
                </div>
                <div class="card-body">
                    <p class="mb-0"><?php echo e($purchase->notes); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <!-- Action Buttons -->
            <div class="card">
                <div class="card-body">
                    <div class="d-grid gap-2">

                        <a href="<?php echo e(route('purchases.edit', $purchase)); ?>" class="btn btn-warning">
                            <i class="bi bi-pencil"></i> Edit Purchase
                        </a>

                        <form action="<?php echo e(route('purchases.destroy', $purchase)); ?>" 
                              method="POST"
                              onsubmit="return confirm('Are you sure?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger w-100">
                                <i class="bi bi-trash"></i> Delete Purchase
                            </button>
                        </form>

                    </div>
                </div>
            </div>

        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mini-ecommerce\resources\views/purchases/show.blade.php ENDPATH**/ ?>